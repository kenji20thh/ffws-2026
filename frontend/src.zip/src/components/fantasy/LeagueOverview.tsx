
"use client";

import Link from "next/link";
import type { FantasyLeague } from "@/types";

export type LeagueStanding =
  | { status: "ok"; rank: number; total: number; points: number }
  | { status: "error" };

export function topPercent(rank: number, total: number): number {
  if (total <= 0) return 100;
  return Math.min(100, Math.max(1, Math.ceil((rank / total) * 100)));
}

function Standing({
  standing,
  teams,
}: {
  standing: LeagueStanding | undefined;
  teams: number;
}) {
  if (!standing) {
    return (
      <div className="shrink-0 space-y-2" aria-label="Loading standing">
        <div className="h-7 w-24 animate-pulse bg-bone/10" />
      </div>
    );
  }

  if (standing.status === "error") {
    return (
      <div className="shrink-0">
        <p className="font-display text-2xl font-black leading-none text-ash">
          —
        </p>
        <p className="mt-1 font-stat text-[9px] uppercase tracking-widest text-ash">
          Unavailable
        </p>
      </div>
    );
  }

  if (standing.total < 2) {
    return (
      <div className="shrink-0">
        <p className="font-display text-2xl font-black uppercase leading-none text-bone">
          Solo
        </p>
        <p className="mt-1 font-stat text-[9px] uppercase tracking-widest text-ash">
          {teams === 1 ? "Only player" : "Standing pending"}
        </p>
      </div>
    );
  }

  const pct = topPercent(standing.rank, standing.total);

  return (
    <div className="shrink-0">
      <p
        className={`whitespace-nowrap font-display text-2xl font-black uppercase leading-none tabular-nums sm:text-3xl ${
          pct <= 10 ? "text-ember" : "text-bone"
        }`}
      >
        Top {pct}%
      </p>
    </div>
  );
}

function LeagueCard({
  league,
  active,
  standing,
  onSelect,
}: {
  league: FantasyLeague;
  active: boolean;
  standing: LeagueStanding | undefined;
  onSelect: () => void;
}) {
  const isPrivate = league.type === "private";

  return (
    <li className="min-w-0">
      <article
        className={`group relative flex min-h-[238px] min-w-0 flex-col overflow-hidden border transition-colors duration-200 sm:min-h-[250px] ${
          active
            ? "border-ember bg-ember/[0.08]"
            : "border-bone/10 bg-char-2 hover:border-ember/60 hover:bg-char-3"
        }`}
      >
        <button
          type="button"
          aria-pressed={active}
          onClick={onSelect}
          className="relative flex min-h-0 flex-1 flex-col items-stretch p-3 text-left sm:p-4"
        >
          <span
            aria-hidden="true"
            className="pointer-events-none absolute -right-2 -top-3 select-none font-display text-[6rem] font-black leading-none text-bone/[0.025] transition-colors group-hover:text-ember/[0.06] sm:text-[7rem]"
          >
            {isPrivate ? "P" : league.type === "global" ? "G" : "R"}
          </span>

          <span className="relative z-10 flex shrink-0 items-center justify-between gap-2">
            <span
              className={`h-1 w-7 transition-all duration-200 group-hover:w-10 ${
                active ? "bg-ember" : "bg-bone/20 group-hover:bg-ember"
              }`}
            />

            {isPrivate && (
              <span
                className="text-xs"
                role="img"
                aria-label="Private league"
                title="Private league"
              >
                🔒
              </span>
            )}
          </span>

          <div className="relative z-10 mt-3 min-w-0">
            <p className="mb-2 font-stat text-[8px] uppercase tracking-[0.12em] text-ash sm:text-[9px] sm:tracking-[0.16em]">
              {isPrivate
                ? "Private competition"
                : league.type === "global"
                  ? "Worldwide"
                  : "Regional competition"}
            </p>

            <h3 className="min-w-0 break-words font-display text-base font-black uppercase leading-[1.05] tracking-tight text-bone transition-colors group-hover:text-ember [overflow-wrap:anywhere] sm:text-lg lg:text-xl">
              {league.name}
            </h3>
          </div>

          <div className="relative z-10 mt-auto shrink-0 pt-5">
            <Standing standing={standing} teams={league.teams} />
          </div>
        </button>

        <div className="relative z-10 flex shrink-0 items-center justify-between gap-3 border-t border-bone/10 px-3 py-3 sm:px-4">
          <div className="min-w-0">
            <p className="font-display text-lg font-bold leading-none tabular-nums text-bone sm:text-xl">
              {league.teams}
            </p>
            <p className="mt-1 font-stat text-[8px] uppercase tracking-widest text-ash sm:text-[9px]">
              {league.teams === 1 ? "Player" : "Players"}
            </p>
          </div>

          <Link
            href={`/fantasy/leagues/${encodeURIComponent(league.slug)}`}
            aria-label={`Open the ${league.name} league page`}
            className="flex h-8 w-8 shrink-0 items-center justify-center border border-bone/10 text-base text-bone/60 transition-colors hover:border-ember hover:bg-ember hover:text-char"
          >
            ↗
          </Link>
        </div>

        <span
          aria-hidden="true"
          className={`absolute bottom-0 left-0 h-[2px] bg-ember transition-all duration-300 ${
            active ? "w-full" : "w-0 group-hover:w-full"
          }`}
        />
      </article>
    </li>
  );
}

function Section({
  title,
  empty,
  leagues,
  active,
  standings,
  onSelect,
}: {
  title: string;
  empty: string;
  leagues: FantasyLeague[];
  active: string;
  standings: Record<string, LeagueStanding>;
  onSelect: (slug: string) => void;
}) {
  return (
    <section aria-label={title}>
      <div className="mb-4 flex items-center gap-3">
        <h2 className="shrink-0 font-stat text-[10px] font-bold uppercase tracking-[0.22em] text-ember sm:text-xs sm:tracking-[0.28em]">
          {title}
        </h2>

        <span className="h-px flex-1 bg-bone/10" />

        <span className="font-stat text-[10px] tabular-nums text-ash">
          {String(leagues.length).padStart(2, "0")}
        </span>
      </div>

      {leagues.length === 0 ? (
        <p className="border border-dashed border-bone/15 px-4 py-5 font-stat text-xs text-ash">
          {empty}
        </p>
      ) : (
        <ul className="grid grid-cols-2 items-stretch gap-3 sm:grid-cols-3 sm:gap-4 xl:grid-cols-4">
          {leagues.map((league) => (
            <LeagueCard
              key={league.slug}
              league={league}
              active={league.slug === active}
              standing={standings[league.slug]}
              onSelect={() => onSelect(league.slug)}
            />
          ))}
        </ul>
      )}
    </section>
  );
}

export default function LeagueOverview({
  leagues,
  active,
  standings,
  onSelect,
}: {
  leagues: FantasyLeague[];
  active: string;
  standings: Record<string, LeagueStanding>;
  onSelect: (slug: string) => void;
}) {
  const general = leagues.filter((league) => league.type !== "private");
  const priv = leagues.filter((league) => league.type === "private");

  return (
    <div className="space-y-8">
      <Section
        title="General leagues"
        empty="No general leagues yet."
        leagues={general}
        active={active}
        standings={standings}
        onSelect={onSelect}
      />

      <Section
        title="Private leagues"
        empty="You haven't joined a private league yet. Create or join one below."
        leagues={priv}
        active={active}
        standings={standings}
        onSelect={onSelect}
      />
    </div>
  );
}

package handlers

import (
	"net/http"
	"strconv"

	"ffws/internal/models"
	"ffws/internal/repository"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

type PlayerHandler struct {
	repo      *repository.PlayerRepository
	statsRepo *repository.PlayerStatsRepository
}

func NewPlayerHandler(
	repo *repository.PlayerRepository,
	statsRepo *repository.PlayerStatsRepository,
) *PlayerHandler {
	return &PlayerHandler{
		repo:      repo,
		statsRepo: statsRepo,
	}
}

type createPlayerRequest struct {
	TeamID   uint   `json:"team_id" binding:"required"`
	IGN      string `json:"ign" binding:"required"`
	RealName string `json:"real_name"`
	Role     string `json:"role"`
	PhotoURL string `json:"photo_url"`
	Region   string `json:"region"`
	Country  string `json:"country"`
	IsCaptain bool  `json:"is_captain"`
}

func (h *PlayerHandler) Create(c *gin.Context) {
	var req createPlayerRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	player := models.Player{
		TeamID:   req.TeamID,
		IGN:      req.IGN,
		RealName: req.RealName,
		Role:     req.Role,
		PhotoURL: req.PhotoURL,
		Region:   req.Region,
		Country:  req.Country,
		IsCaptain: req.IsCaptain,
	}

	if err := h.repo.Create(&player); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to create player"})
		return
	}

	c.JSON(http.StatusCreated, gin.H{"data": player})
}

func (h *PlayerHandler) List(c *gin.Context) {
	teamIDStr := c.Query("team_id")
	if teamIDStr == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "team_id query param is required"})
		return
	}

	teamID, err := strconv.ParseUint(teamIDStr, 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid team_id"})
		return
	}

	players, err := h.repo.FindByTeam(uint(teamID))
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to fetch players"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"data": players})
}

func (h *PlayerHandler) GetByID(c *gin.Context) {
	idStr := c.Param("id")

	id, err := strconv.ParseUint(idStr, 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid player id"})
		return
	}

	profile, err := h.statsRepo.GetProfile(uint(id))
	if err != nil {
		if err == gorm.ErrRecordNotFound {
			c.JSON(http.StatusNotFound, gin.H{"error": "player not found"})
			return
		}

		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "failed to fetch player profile",
		})
		return
	}

	c.JSON(http.StatusOK, gin.H{"data": profile})
}

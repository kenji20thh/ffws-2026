package handlers

import (
	"errors"
	"log"
	"net/http"
	"strconv"

	"ffws/internal/repository"

	"github.com/gin-gonic/gin"
)

type RoomResultHandler struct {
	repo *repository.RoomResultRepository
}

func NewRoomResultHandler(repo *repository.RoomResultRepository) *RoomResultHandler {
	return &RoomResultHandler{repo: repo}
}

type submitPlayerResult struct {
	PlayerID   uint `json:"player_id" binding:"required"`
	Kills      int  `json:"kills" binding:"gte=0,lte=100"`
	FirstBlood bool `json:"first_blood"`
}

type submitTeamResult struct {
	TeamID    uint                 `json:"team_id" binding:"required"`
	Placement int                  `json:"placement" binding:"required,gte=1,lte=12"`
	Players   []submitPlayerResult `json:"players" binding:"required,min=1,dive"`
}

type submitRoomResultsRequest struct {
	Teams []submitTeamResult `json:"teams" binding:"required,min=1,dive"`
}

// Submit accepts one team or many teams in the same request body.
// A single team can be sent right as it dies, or several at once — both work.
func (h *RoomResultHandler) Submit(c *gin.Context) {
	roomIDStr := c.Param("id")
	roomID, err := strconv.ParseUint(roomIDStr, 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid room id"})
		return
	}

	var req submitRoomResultsRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	var teams []repository.TeamResultInput
	for _, t := range req.Teams {
		var players []repository.PlayerKillInput
		for _, p := range t.Players {
			players = append(players, repository.PlayerKillInput{
				PlayerID:   p.PlayerID,
				Kills:      p.Kills,
				FirstBlood: p.FirstBlood,
			})
		}
		teams = append(teams, repository.TeamResultInput{
			TeamID:    t.TeamID,
			Placement: t.Placement,
			Players:   players,
		})
	}

	if err := h.repo.SubmitRoomResults(uint(roomID), teams); err != nil {
		var resErr *repository.ResultError
		switch {
		case errors.Is(err, repository.ErrRoomNotFound):
			c.JSON(http.StatusNotFound, gin.H{"error": err.Error()})
		case errors.As(err, &resErr):
			c.JSON(http.StatusBadRequest, gin.H{"error": resErr.Error()})
		default:
			log.Printf("submit room results failed: %v", err)
			c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to submit results"})
		}
		return
	}

	c.JSON(http.StatusCreated, gin.H{"message": "results submitted successfully"})
}

func (h *RoomResultHandler) GetSummary(c *gin.Context) {
	roomIDStr := c.Param("id")
	roomID, err := strconv.ParseUint(roomIDStr, 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid room id"})
		return
	}

	summary, err := h.repo.GetRoomSummary(uint(roomID))
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to fetch room summary"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"data": summary})
}

func (h *RoomResultHandler) GetStandings(c *gin.Context) {
	tournamentIDStr := c.Query("tournament_id")
	if tournamentIDStr == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "tournament_id query param is required"})
		return
	}
	tournamentID, err := strconv.ParseUint(tournamentIDStr, 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid tournament_id"})
		return
	}

	standings, err := h.repo.GetTournamentStandings(uint(tournamentID))
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to fetch standings"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"data": standings})
}

// GetPlayerStats returns the saved per-player lines of a room so the admin panel can
// re-open a room with its already-entered stats. Admin only (not cached).
func (h *RoomResultHandler) GetPlayerStats(c *gin.Context) {
	roomID, err := strconv.ParseUint(c.Param("id"), 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid room id"})
		return
	}

	rows, err := h.repo.GetRoomPlayerStats(uint(roomID))
	if err != nil {
		log.Printf("fetch room player stats failed: %v", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to fetch player stats"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"data": rows})
}

// GetPenalties lists the penalties of every day of a tournament (public, read-only).
// Penalties are added directly in the database.
func (h *RoomResultHandler) GetPenalties(c *gin.Context) {
	tournamentID, err := strconv.ParseUint(c.Query("tournament_id"), 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "valid tournament_id query param is required"})
		return
	}

	rows, err := h.repo.GetTournamentPenalties(uint(tournamentID))
	if err != nil {
		log.Printf("fetch penalties failed: %v", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to fetch penalties"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"data": rows})
}

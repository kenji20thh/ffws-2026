package handlers

import (
	"errors"
	"net/http"
	"strconv"

	"ffws/internal/repository"

	"github.com/gin-gonic/gin"
)

type PredictionHandler struct {
	repo *repository.PredictionRepository
}

func NewPredictionHandler(repo *repository.PredictionRepository) *PredictionHandler {
	return &PredictionHandler{repo: repo}
}

type placementPick struct {
	TeamID uint `json:"team_id" binding:"required"`
	// Session is the lobby the team plays in that day (1 if omitted). Placement is
	// 1-12 within that session.
	Session   int `json:"session" binding:"omitempty,gte=1,lte=10"`
	Placement int `json:"placement" binding:"required,gte=1,lte=12"`
}

// One pick per team on the day: 12 per session, so the length is validated in the
// repository against the day's actual sessions.
type submitPredictionRequest struct {
	Picks []placementPick `json:"picks" binding:"required,min=12,max=120,dive"`
}

func (h *PredictionHandler) Submit(c *gin.Context) {
	userID := c.GetUint("user_id")
	dayID, err := strconv.ParseUint(c.Param("dayId"), 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid day id"})
		return
	}

	var req submitPredictionRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	picks := make([]repository.PlacementInput, 0, len(req.Picks))
	for _, p := range req.Picks {
		session := p.Session
		if session == 0 {
			session = 1
		}
		picks = append(picks, repository.PlacementInput{TeamID: p.TeamID, Session: session, Placement: p.Placement})
	}

	prediction, err := h.repo.SubmitPrediction(userID, uint(dayID), picks)
	if err != nil {
		status := http.StatusBadRequest
		if errors.Is(err, repository.ErrPredictionLocked) {
			status = http.StatusConflict
		} else if errors.Is(err, repository.ErrNoCompetitorTeam) {
			status = http.StatusNotFound
		}
		c.JSON(status, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusCreated, gin.H{"data": prediction})
}

func (h *PredictionHandler) GetMine(c *gin.Context) {
	userID := c.GetUint("user_id")
	dayID, err := strconv.ParseUint(c.Param("dayId"), 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid day id"})
		return
	}

	result, err := h.repo.GetByUserAndDay(userID, uint(dayID))
	if err != nil {
		status := http.StatusInternalServerError
		if errors.Is(err, repository.ErrPredictionNotFound) || errors.Is(err, repository.ErrNoCompetitorTeam) ||
			errors.Is(err, repository.ErrDayNotFound) {
			status = http.StatusNotFound
		}
		c.JSON(status, gin.H{"error": err.Error()})
		return
	}
	lockTime, _ := h.repo.GetDayLockTime(uint(dayID))

	c.JSON(http.StatusOK, gin.H{"data": gin.H{
		"prediction": result.Prediction, "teams": result.Teams,
		"total_points": result.TotalPoints, "scored": result.Scored,
		"locked": result.Locked, "hidden": false,
		"lock_time": lockTime,
	}})
}

func (h *PredictionHandler) GetByID(c *gin.Context) {
	id, err := strconv.ParseUint(c.Param("id"), 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid prediction id"})
		return
	}

	// user_id is only set when a valid token was sent (OptionalAuth); 0 = anonymous.
	result, err := h.repo.GetByID(uint(id), c.GetUint("user_id"))
	if err != nil {
		status := http.StatusInternalServerError
		if errors.Is(err, repository.ErrPredictionNotFound) {
			status = http.StatusNotFound
		}
		c.JSON(status, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"data": gin.H{
		"prediction": result.Prediction, "teams": result.Teams,
		"total_points": result.TotalPoints, "scored": result.Scored,
		"locked": result.Locked, "hidden": result.Hidden,
	}})
}

func (h *PredictionHandler) GetStandings(c *gin.Context) {
	tournamentID, err := strconv.ParseUint(c.Query("tournament_id"), 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "tournament_id query param is required"})
		return
	}
	var dayIDPtr *uint
	if dayIDStr := c.Query("day_id"); dayIDStr != "" {
		dayID, err := strconv.ParseUint(dayIDStr, 10, 32)
		if err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": "invalid day_id"})
			return
		}
		d := uint(dayID)
		dayIDPtr = &d
	}
	standings, err := h.repo.GetStandings(uint(tournamentID), dayIDPtr)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to fetch standings"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"data": standings})
}
